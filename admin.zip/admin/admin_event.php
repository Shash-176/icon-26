<?php
session_start();
// $servername = "localhost";
// $username = "root";
// $password = "";
// $database = "player_detail";
// $conn = mysqli_connect($servername,$username,$password,$database);

 $servername = "localhost";
    $username = "u419687700_Icon2022"; 
    $password = "IconKJ@2022";
    $database = "u419687700_player_detail";
$conn = mysqli_connect($servername,$username,$password,$database);

if (!$conn) {
	echo"data error";
}
// $sql = " SELECT * FROM payment_details ";

// $sql1 = " SELECT * FROM team_member_details ";

// $result1=mysqli_query($conn,$sql1);
// if($result1)
// {
//   //  echo "team_member_details successfully";
// }
// else
// {
//   //  echo "team_member_details unsuccessfully<br>".mysqli_error($conn);
// }


// $result = $mysqli->query($sql);
// $result=mysqli_query($conn,$sql);
// if($result)
// {
//   //  echo "loggedin successfully";
// }
// else
// {
//   //  echo "loggin unsuccessfully<br>".mysqli_error($conn);
// }

if(isset($_GET['event_name'])||isset($_POST['event_name']))
{
if(
  $_GET['event_name'] == 'valorant'||
  $_GET['event_name'] == 'gallery' || 
  $_GET['event_name'] == 'cricket'||
 $_GET['event_name'] == 'codeicon'||
 $_GET['event_name'] == 'treasure_hunt' ||
 $_GET['event_name'] == 'tech_knowledge')
 {
  //echo"<script>alert('213')</script>";
      $event=$_GET['event_name'];
     $team_detail="SELECT * from team_details where game='".$event."'";
   
     $result1=mysqli_query($conn,$team_detail);
     
     while($resultteam=$result1->fetch_assoc())
                {
   //echo"".$resultteam['teamname'];
                }


     $team_member="SELECT * from team_member_details WHERE game='".$event."'";
    
     $result_member1=mysqli_query($conn,$team_member);
     while($resulmember=$result_member1->fetch_assoc())
                {
                  
                }
 }

}

if(isset($_SESSION['designation']))
{
  $designation=$_SESSION['designation'];
  // if($designation=='EC_team')
  // {
  //   echo"<script>alert('1');<script>";
  //   $event=$_SESSION['event_name'];
  //   $team_detail="SELECT * from team_details WHERE event_name='".$event."'";
  //   $result1=mysqli_query($conn,$team_detail);

  //   $team_member="SELECT * from team_member_details WHERE event_name='".$event."'";
  //   echo"<br/>".$team_member;
  //   $result_member1=mysqli_query($conn,$team_member);
  // }
  // elseif($designation=='EC_solo')
  // {
  //   $event=$_SESSION['event_name'];
  //   $solo="SELECT * from solo WHERE event_name='".$event."'";
    

    
  // }

  // if($designation=='admin')
  // {
  //   $team_detail="SELECT * from team_details";
  //   $result1=mysqli_query($conn,$team_detail);

  //   $team_member="SELECT * from team_member_details ";
  //   $result_member1=mysqli_query($conn,$team_member);
  //   //code for payments
  // }





}
else
    {
        header('location:logout.php');
    }


// session_start();

// if(!isset($_SESSION['admin_name'])){
//    header('location:index.php');
// }

/*----------------------------------------------------------------------*/
// $mysqli->close();
// if ($_SERVER["REQUEST_METHOD"] == "GET")
// {
//   echo"<script>alert('1')</script>";
//   $srno = $_GET['edit'];
//   $status = $_GET['status'];
//   echo"<script>alert('".$status."')</script>";
//   $sql = "SELECT * FROM payment_details WHERE srno = ".$srno;
//  echo"<script>alert('".$sql."')</script>";

//   // while($rows=$result->fetch_assoc())
// 	// 			{
          
//   //       }
  
// }
?>
<!DOCTYPE html>
<html lang="en">

<head>
<meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- <link rel="stylesheet" type="text/css" href="style.css">  -->
    <link rel="stylesheet" href="../assets/lib/bootstrap/css/bootstrap.min.css"/>
    <title>Document</title>
	<style>
    body{
      margin: 10px;
      background: #4B79A1;
      background: -webkit-linear-gradient(to left, #4B79A1 , #283E51);
      background: linear-gradient(to left, #4B79A1 , #283E51);       
    }
    h2{
      color: white;
    text-align: center;
    }
    tr{
      background: lightskyblue;
    }
    td{
      background-color: white;
      color: black;
    }
		table {
			margin: 0 auto;
			font-size: large;
			border: 2px solid black;
      border-radius: 10px;
		}

		h1 {
			text-align: center;
			color: #006600;
			font-size: xx-large;
			font-family: 'Gill Sans', 'Gill Sans MT',
			' Calibri', 'Trebuchet MS', 'sans-serif';
		}

		td {
			background-color: #E4F5D4;
			border: 1px solid black;
		}

		th,
		td {
			font-weight: bold;
			border: 1px solid black;
			padding: 10px;
			text-align: center;
		}

		td {
			font-weight: lighter;
		}
    #logoutbtn{
      background: red;
      color: white;
      padding: 5px 10px 5px 10px;
      margin: 10px;
      border-radius: 5px;
      float: right;
    }
    @media only screen and (min-width:768px)
    {
    .team-det
    {
        display:inline-table;
    }
    }
	</style>
</head>

<body>

<header id="header">
  
    
  </header>  
  <!-- <div id="rotate" class="rotate">
  <img id="rotatephone" src="phonerotate.png" height="200px" width="200px" style="display: block;" alt="">
  <p>Rotate your phone screen</p>
  </div> -->
    <div class="container-fluid datatable" >
        <div class="row">
          
          <div class="col-md-12">
            <form action="" method="GET">
            <?php
              if(!isset($_GET['event_name']))
              {
                echo"<h4 class='text-white'>Please select an Event from the drop down to see the details</h4>";
              }
              ?>
             <select name="event_name" id="" placeholder="Please Select an Event" required>
              <option value="">--Select Event--</option>
              <option value="Big_chess">Big Chess</option>
              <option value="codeicon">CodeIcon</option>
              <option value="coding_decoding">Coding/Decoding</option>
              <option value="content_writing">Content Writing</option>
              <option value="creatography">Creatography</option>
              <option value="cricket">Cricket</option>
              <option value="gallery">Gallery</option>
              <option value="tech_knowledge">Tech Knowledge</option>
              <option value="treasure_hunt">Treasure Hunt</option>
              <option value="valorant">Valorant</option>
              <option value="web_design">Web Designing</option>
              
             </select>
              <input type="submit" name="" value="Fetch Record"/>
            </form>
            <a class="btn btn-dark" href="pay_details.php">Payments</a>
            <a href="logout.php" value="logout" id="logoutbtn">Logout</a>

          <?php 
              // $_GET['event_name'] == 'csgo' ||
              // $_GET['event_name'] == 'valorant' ||
              // $_GET['event_name'] == 'Big_chess' ||
              // $_GET['event_name'] == 'web_design' ||
              // $_GET['event_name'] == 'coding_decoding' ||
              // $_GET['event_name'] == 'treasure_hunt' ||
              // $_GET['event_name'] == 'tech_knowledge' ||
              // $_GET['event_name'] == 'creatography' ||
              // $_GET['event_name'] == 'content_writing' ||
              // $_GET['event_name'] == 'cricket' ||
              // $_GET['event_name'] == 'football' ||
              // $_GET['event_name'] == 'drag and drop'|| 
              // $_GET['event_name'] == 'gallery'||
              // $_GET['event_name'] == 'codeicon'


              // if(isset())
              //   {
              
                if(isset($_GET['event_name'])||isset($_POST['event_name']))
{
    
     if(
      $_GET['event_name'] == 'valorant'||
      $_GET['event_name'] == 'gallery' || 
      $_GET['event_name'] == 'cricket'||
     $_GET['event_name'] == 'codeicon'||
     $_GET['event_name'] == 'treasure_hunt' ||
     $_GET['event_name'] == 'tech_knowledge')
     {
      // echo"<script>alert('213')</script>";
      //     $event=$_GET['event_name'];
      //    $team_detail="SELECT * from team_details where eventname='".$event."'";
      //   //echo"".$team_detail;
      //    $result1=mysqli_query($conn,$team_detail);

      //    $team_member="SELECT * from team_member_details WHERE game='".$event."'";
      //    echo"<br/>".$team_member;
      //    $result_member1=mysqli_query($conn,$team_member);


    ?>
<h2>Team Details <?php echo"".ucfirst(str_replace("_"," ",$_GET['event_name'])).""; ?></h2>
          <table class="table table-responsive">
          <tr>
                <th>Sr.No</th>
                <th>TeamName</th>
                <th>Team Leader Name</th>                
                <th>Phone no</th>
                <th>Alternate Phone no</th>
                <th>Email</th>
                <th>College Name</th>
                <th>College id</th>
                <th>Game</th>
                <th>Summary</th>
                <th>Team Details</th>
              </tr>

              <?php
               $event=$_GET['event_name'];
               $team_detail="SELECT * from team_details where game='".$event."'";
              // echo"".$team_detail;
               $result1=mysqli_query($conn,$team_detail);
               
               while($resultteam=$result1->fetch_assoc())
                          {
                  
              ?>

            <tr>
                
                <td><?php echo $resultteam['teamdetail_id']; ?></td>
                <td><?php echo $resultteam['teamname']; ?></td>
                <td><?php echo $resultteam['teamleader_name']; ?></td>
                <td><?php echo $resultteam['contact']; ?></td>
                <td><?php echo $resultteam['secondarycontact']; ?></td>
                <td><?php echo $resultteam['email']; ?></td>
                <td><?php echo $resultteam['clg_name']; ?></td>
                <td><a href="../upload/<?php echo $resultteam['clgproof']; ?>" target="_blank"><?php echo $resultteam['clgproof']; ?></a></td>
                <td><?php echo $resultteam['game']; ?></td>
                <td><a href="../summary_gallery/<?php echo $resultteam['summarypdf']; ?>" target="_blank" ><?php echo $resultteam['summarypdf']; ?></a></td>
                <td><a href="admin_event.php?event_name=<?php echo $resultteam['game']; ?>&team_name=<?php echo $resultteam['teamname']; ?>">get details</a></td>
                
              </tr>
              <?php 
              
                }

               
                ?>
          </table>
          <?php
 if(isset($_GET['team_name']))
 {
   $teamname=$_GET['team_name'];
   if($_GET['event_name']!='codeicon')
   {
   $team_member="SELECT * from team_member_details WHERE game='".$event."' AND teamname='".$teamname."'";
 //echo"<br/>".$team_member;
 $result_member1=mysqli_query($conn,$team_member);
 
?>
          <h2>Team Member Details of <?php echo $teamname; ?></h2>
          <table class="table table-responsive team-det">
          <tr>
             
                <th>Sr.No</th>
                <th>TeamName</th>                         
                <th>Game</th>
                <th>Member Name</th>
                <th>In Game Name</th>
                <th>College Name</th>
               
                
              </tr>

              <?php 
              
              
     while($resulmember=$result_member1->fetch_assoc())
                {
                 
                  
              
                ?>
              <tr>
               
                <td><?php echo $resulmember['tmdid']; ?></td>
                <td><?php echo $resulmember['teamname']; ?></td>
                <td><?php echo $resulmember['game']; ?></td>
                <td><?php echo $resulmember['Member_Name']; ?></td>
                <td><?php echo $resulmember['In_game_name']; ?></td>
                <td><?php echo $resulmember['clg_name']; ?></td>
               
               
                
              </tr>
              <?php
                }   }
 }
                ?>
          </table>
          
<?php
}
if(( $_GET['event_name'] == 'codeicon' && isset($_GET['team_name']) ) ||
   ( $_GET['event_name'] == 'gallery'  && isset($_GET['team_name']) )  )
{
  
  $teamname=$_GET['team_name'];
   $team_member="SELECT * from codeicon_team_member_details WHERE game='".$_GET['event_name']."' AND teamname='".$teamname."'";
 //echo"<br/>".$team_member;
 $result_member1=mysqli_query($conn,$team_member);
?>
 <h2>Team Member Details of <?php echo $teamname; ?></h2>
          <table>
            <tr>
              <th>Sr no.</th>
              <th>Team Name</th>
              <th>Member Name </th>
              <th>Email id</th>
              <th>Mobile no.</th>
              <th>College</th>
              
            </tr>
            <?php             
     while($resulmember=$result_member1->fetch_assoc())
                {
                  //
            ?>
            <tr>
           
            <td><?php echo $resulmember['tmdid']; ?></td>
                <td><?php echo $resulmember['teamname']; ?></td>
               
                <td><?php echo $resulmember['Member_Name']; ?></td>
                <td><?php echo $resulmember['email']; ?></td>
                <td><?php echo $resulmember['contact']; ?></td>
                <td><?php echo $resulmember['clg_name']; ?></td>
            </tr>
            <?php
                }
            ?>
          </table>
    <?php 
     }

     elseif(
     $_GET['event_name'] == 'web_design' ||
     $_GET['event_name'] == 'creatography' ||
     $_GET['event_name'] == 'content_writing' ||
     $_GET['event_name'] == 'Big_chess' ||
     $_GET['event_name'] == 'drag and drop' ||
     $_GET['event_name'] == 'coding_decoding')
     {

      ?>
      <h2 class="text-center">SOLO Event Detail <?php echo"".ucfirst(str_replace("_"," ",$_GET['event_name'])).""; ?></h2>
<table class="table table-responsive">
           
           <tr>
                 <th>Sr.No</th>
                 <th>Participant Name</th>                         
                 <th>Mobile No</th>
                 <th>Alternate Contact</th>
                 <th>Email</th>
                 <th>College Name</th>
                 <th>id card</th>
                 <th>Game</th>
                 
               </tr>

<?php
      $event=$_GET['event_name'];
      $solo="SELECT * FROM solo where eventname='".$event."'";
      $result2=mysqli_query($conn,$solo);
      while($resultsolo=$result2->fetch_assoc())
         {

?>
 <tr>
                
                <td><?php echo $resultsolo['id']; ?></td>
                <td><?php echo $resultsolo['playername']; ?></td>
                <td><?php echo $resultsolo['contact']; ?></td>
                <td><?php echo $resultsolo['alternatecontact']; ?></td>
                <td><?php echo $resultsolo['email']; ?></td>
                <td><?php echo $resultsolo['clg_name']; ?></td>
                <td><a href="../upload/<?php echo $resultsolo['clgproof']; ?>" target="_blank"><?php echo $resultsolo['clgproof']; ?></a></td>
                <td><?php echo $resultsolo['eventname']; ?></td>
               
                
                
              </tr>



<?php
       }
       ?>
           </table>
         <?php
         
    }
}
              ?>
         
<br>

        





                   </div>
          
        </div>
      
      </div>



</body>

</html>
