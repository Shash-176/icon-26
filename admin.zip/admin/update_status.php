<?php
@include 'config.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $srno = $_POST["srno"];
    $newStatus = $_POST["new_status"];

    // Update the status in the "payment_details" table
    $sql = "UPDATE payment_details SET status = ? WHERE srno = ?";
    $stmt = $conn->prepare($sql);

    if ($stmt === false) {
        die("Error in the database update.");
    }

    $stmt->bind_param("ii", $newStatus, $srno);
    $stmt->execute();

    $stmt->close();
}

// Close the database connection
$conn->close();

// Redirect back to the previous page
header("Location: ".$_SERVER['HTTP_REFERER']);
exit;
?>